"""Train and save the RouteOptix delivery-time regression model."""
from pathlib import Path
import pickle
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

BASE_DIR = Path(__file__).parent
data = pd.read_csv(BASE_DIR / "data" / "delivery_gps_dataset.csv")
features = ["distance_km", "package_weight_kg", "traffic", "weather", "vehicle_type"]
target = "actual_delivery_minutes"

X, y = data[features], data[target]
numeric, categorical = ["distance_km", "package_weight_kg"], ["traffic", "weather", "vehicle_type"]
preprocessor = ColumnTransformer([
    ("number", SimpleImputer(strategy="median"), numeric),
    ("category", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train_ready = preprocessor.fit_transform(X_train)
model = RandomForestRegressor(n_estimators=150, random_state=42)
model.fit(X_train_ready, y_train)
prediction = model.predict(preprocessor.transform(X_test))
print(f"MAE: {mean_absolute_error(y_test, prediction):.2f}")
print(f"RMSE: {mean_squared_error(y_test, prediction) ** 0.5:.2f}")
print(f"R²: {r2_score(y_test, prediction):.2f}")
(BASE_DIR / "models").mkdir(exist_ok=True)
with open(BASE_DIR / "models" / "delivery_time_model.pkl", "wb") as file: pickle.dump(model, file)
with open(BASE_DIR / "models" / "preprocessor.pkl", "wb") as file: pickle.dump(preprocessor, file)
print("Model saved in models/.")
