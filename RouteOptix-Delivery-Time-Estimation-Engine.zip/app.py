from pathlib import Path
import pickle
import random
from datetime import datetime, timedelta

import numpy as np
from flask import Flask, jsonify, render_template, request

BASE_DIR = Path(__file__).parent
MODEL_PATH = BASE_DIR / "models" / "delivery_time_model.pkl"
PREPROCESSOR_PATH = BASE_DIR / "models" / "preprocessor.pkl"

app = Flask(__name__)

MODEL = PREPROCESSOR = None
if MODEL_PATH.exists() and PREPROCESSOR_PATH.exists():
    with open(MODEL_PATH, "rb") as model_file, open(PREPROCESSOR_PATH, "rb") as prep_file:
        MODEL, PREPROCESSOR = pickle.load(model_file), pickle.load(prep_file)


def sample_deliveries():
    random.seed(24)
    rows = []
    routes = [("Central Hub", "North City"), ("Central Hub", "Airport"), ("East Hub", "Old Town"),
              ("West Hub", "Tech Park"), ("South Hub", "Lake View")]
    for i in range(1, 51):
        distance = random.randint(3, 42)
        traffic = random.choice(["Low", "Medium", "High"])
        estimate = round(18 + distance * 2.6 + {"Low": 0, "Medium": 11, "High": 25}[traffic] + random.uniform(-5, 5))
        actual = estimate + random.randint(-10, 22)
        source, destination = random.choice(routes)
        rows.append({"id": f"DLV-{1000+i}", "driver": random.choice(["Arun K.", "Neha S.", "Vikram P.", "Riya M."]),
                     "route": f"{source} → {destination}", "distance": distance, "traffic": traffic,
                     "estimated": estimate, "actual": actual, "delay": max(0, actual-estimate),
                     "status": "On Time" if actual <= estimate + 10 else "Delayed",
                     "date": (datetime.now() - timedelta(days=random.randint(0, 20))).strftime("%Y-%m-%d")})
    return rows


DELIVERIES = sample_deliveries()


@app.route("/")
def login():
    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/predict")
def predict_page():
    return render_template("predict.html")


@app.route("/analytics")
def analytics():
    return render_template("analytics.html")


@app.route("/performance")
def performance():
    return render_template("performance.html")


@app.route("/api/dashboard")
def dashboard_data():
    on_time = sum(x["status"] == "On Time" for x in DELIVERIES)
    return jsonify({
        "metrics": {"total": len(DELIVERIES), "onTime": on_time, "delayed": len(DELIVERIES)-on_time,
                    "avgTime": round(np.mean([x["estimated"] for x in DELIVERIES])),
                    "avgDistance": round(np.mean([x["distance"] for x in DELIVERIES]), 1)},
        "deliveries": DELIVERIES,
        "weekly": [31, 42, 36, 48, 55, 46, 39]
    })


@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    distance = float(data.get("distance", 0))
    weight = float(data.get("weight", 0))
    traffic = data.get("traffic", "Medium")
    weather = data.get("weather", "Clear")
    vehicle = data.get("vehicle", "Bike")
    if distance <= 0:
        return jsonify({"error": "Distance must be greater than zero."}), 400
    if MODEL and PREPROCESSOR:
        import pandas as pd
        values = pd.DataFrame([[distance, weight, traffic, weather, vehicle]], columns=["distance_km", "package_weight_kg", "traffic", "weather", "vehicle_type"])
        minutes = round(float(MODEL.predict(PREPROCESSOR.transform(values))[0]))
    else:
        minutes = round(16 + distance * 2.7 + weight * 1.1 + {"Low": 0, "Medium": 12, "High": 27}.get(traffic, 12)
                        + {"Clear": 0, "Rainy": 12, "Foggy": 15}.get(weather, 0)
                        + {"Bike": 0, "Van": 6, "Truck": 10}.get(vehicle, 0))
    risk = "High" if traffic == "High" or weather in ["Rainy", "Foggy"] else ("Medium" if distance > 25 else "Low")
    advice = {"Low": "Route conditions look favourable for an on-time delivery.",
              "Medium": "Allow a small buffer for usual route delays.",
              "High": "Heavy traffic or weather may delay this order; consider dispatching early."}[risk]
    arrival = datetime.now() + timedelta(minutes=minutes)
    return jsonify({"minutes": minutes, "hours": f"{minutes//60}h {minutes%60}m", "window": f"{arrival.strftime('%I:%M %p')} – {(arrival + timedelta(minutes=20)).strftime('%I:%M %p')}", "risk": risk, "advice": advice})


if __name__ == "__main__":
    app.run(debug=True)
