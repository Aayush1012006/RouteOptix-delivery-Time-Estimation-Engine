# RouteOptix – Delivery Time Estimation Engine

RouteOptix is a Diploma final-year internship project that predicts package delivery time from distance, traffic, weather, vehicle type, package weight, and historical delivery information.

## Features
- Static admin login (`admin` / `Admin@123`)
- Delivery performance dashboard and route analytics
- Live delivery-time prediction through a Flask API
- CSV data cleaning, Random Forest regression training, and Pickle model storage

## Install and run
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python train_model.py   # optional; app uses a safe estimate until trained
python app.py
```
Open `http://127.0.0.1:5000`.

## Dataset
`data/delivery_gps_dataset.csv` is a small sample. Replace it with a Delivery and GPS Dataset retaining the fields documented in `train_model.py`.

## Future improvements
Connect live map/traffic APIs, add driver authentication, use GPS coordinates for route distance, and deploy the project to cloud hosting.
